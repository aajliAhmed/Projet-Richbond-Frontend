package com.example.Richbondbakend.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Merchendiseur {
    @Id
    @GeneratedValue
    private Long id;
    private String nom;
    private String prenom;
    private String region;
    private String ville;
    private String marqueCouverte;
    // Richbond/Simmons ou Révey/Atlas ou Total rayons
    private String localisation;
    private String status;
    private String  type;



    private String email;
    private String telephone;
    @ElementCollection
    @CollectionTable(name = "merchandiseur_magasins",
            joinColumns = @JoinColumn(name = "merchandiseur_id"))
    @Column(name = "magasin_id")
    @JsonIgnoreProperties({"magasinIds", "superviseur"})
    private List<Long> magasinIds = new ArrayList<>();
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getTelephone() {
        return telephone;
    }

    public List<Long> getMagasinIds() {
        return magasinIds;
    }

    public void setMagasinIds(List<Long> magasinIds) {
        this.magasinIds = magasinIds;
    }


    @ManyToOne
    @JoinColumn(name = "superviseur_id")
    @com.fasterxml.jackson.annotation.JsonBackReference
    private superviseur superviseur;

    @ElementCollection
    private List<String> marques;
    private List<String> enseignes;

    public List<String> getEnseignes() {
        return enseignes;
    }

    public void setEnseignes(List<String> enseignes) {
        this.enseignes = enseignes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getMarqueCouverte() {
        return marqueCouverte;
    }

    public void setMarqueCouverte(String marqueCouverte) {
        this.marqueCouverte = marqueCouverte;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public superviseur getSuperviseur() {
        return superviseur;
    }

    public void setSuperviseur(superviseur superviseur) {
        this.superviseur = superviseur;
    }


    public List<String> getMarques() {
        return marques;
    }

    public void setMarques(List<String> marques) {
        this.marques = marques;
    }
}
