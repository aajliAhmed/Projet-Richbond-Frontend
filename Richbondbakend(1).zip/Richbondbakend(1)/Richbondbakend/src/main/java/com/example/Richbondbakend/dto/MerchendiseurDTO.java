package com.example.Richbondbakend.dto;

import com.example.Richbondbakend.entity.Merchendiseur;
import java.util.List;

public class MerchendiseurDTO {
    private Long id;
    private String nom;
    private String prenom;
    private String region;
    private String ville;
    private String marqueCouverte;
    private String localisation;
    private String status;
    private String type;
    private String email;
    private String telephone;
    private List<String> marques;
    private List<String> enseignes;

    // Constructeur qui prend l'entité
    public MerchendiseurDTO(Merchendiseur m) {
        this.id = m.getId();
        this.nom = m.getNom();
        this.prenom = m.getPrenom();
        this.region = m.getRegion();
        this.ville = m.getVille();
        this.marqueCouverte = m.getMarqueCouverte();
        this.localisation = m.getLocalisation();
        this.status = m.getStatus();
        this.type = m.getType();
        this.email = m.getEmail();
        this.telephone = m.getTelephone();
        this.marques = m.getMarques();
        this.enseignes = m.getEnseignes();
    }

    // Constructeur par défaut (nécessaire pour la désérialisation)
    public MerchendiseurDTO() {}

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getMarqueCouverte() {
        return marqueCouverte;
    }

    public void setMarqueCouverte(String marqueCouverte) {
        this.marqueCouverte = marqueCouverte;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public List<String> getMarques() {
        return marques;
    }

    public void setMarques(List<String> marques) {
        this.marques = marques;
    }

    public List<String> getEnseignes() {
        return enseignes;
    }

    public void setEnseignes(List<String> enseignes) {
        this.enseignes = enseignes;
    }
}