package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Planification;

import java.time.LocalDateTime;
import java.util.List;

public interface PlanificationService {

    // CRUD de base
    Planification savePlanification(Planification planification);
    Planification updatePlanification(Long id, Planification planification);
    void deletePlanification(Long id);
    Planification getPlanificationById(Long id);
    List<Planification> getAllPlanifications();

    // Récupérer les planifications par merchandiser
    List<Planification> getPlanificationsByMerchandiserId(Long merchandiserId);

    // Récupérer les planifications par magasin
    List<Planification> getPlanificationsByMagasinId(Long magasinId);

    // Récupérer les planifications par date
    List<Planification> getPlanificationsByDate(LocalDateTime dateVisite);

    // Filtrer par période
    List<Planification> getPlanificationsBetweenDates(LocalDateTime start, LocalDateTime end);

    // Récupérer les planifications valides ou invalides
    List<Planification> getPlanificationsByValidationStatus(boolean valide);

    // Récupérer les planifications par statut
    List<Planification> getPlanificationsByStatut(String statut);

    // Méthode pour valider une planification
    Planification validerPlanification(Long id);

    // Générer le planning hebdomadaire pour un merchandiser donné
    List<Planification> getPlanningHebdomadaire(Long merchandiserId, LocalDateTime startOfWeek);

    // Générer le planning journalier
    List<Planification> getPlanningJournalier(Long merchandiserId, LocalDateTime date);
}
