package com.example.Richbondbakend.entity;

public enum StatutVisite {
    PLANIFIEE,
    EN_COURS,
    EFFECTUEE,
    REPROGRAMMEE,
    NON_ACCOMPLIE
}
