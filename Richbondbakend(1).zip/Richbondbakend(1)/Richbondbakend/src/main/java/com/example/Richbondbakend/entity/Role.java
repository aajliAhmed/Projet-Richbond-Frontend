package com.example.Richbondbakend.entity;

public enum Role {
    ADMIN, SUPERVISEUR, MERCHANDISEUR_MONO, MERCHANDISEUR_MULTI
}
