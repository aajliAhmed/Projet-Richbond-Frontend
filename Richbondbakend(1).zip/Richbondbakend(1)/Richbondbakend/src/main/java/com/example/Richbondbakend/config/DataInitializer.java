package com.example.Richbondbakend.config;

import com.example.Richbondbakend.entity.user;
import com.example.Richbondbakend.repository.userRepository;
import com.example.Richbondbakend.entity.Role;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initDatabase(userRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            // Création de l'admin
            if (userRepository.findByUsername("admin").isEmpty()) {
                user admin = new user();
                admin.setUsername("admin");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setRole(Role.ADMIN);
                userRepository.save(admin);
                System.out.println("✅ Admin user created: admin / admin123");
            } else {
                System.out.println("ℹ️ Admin user already exists.");
            }

            // ✅ Création du marchandiseur
            if (userRepository.findByUsername("marchand").isEmpty()) {
                user marchand = new user();
                marchand.setUsername("marchand");
                marchand.setPassword(passwordEncoder.encode("merch123"));
                marchand.setRole(Role.MERCHANDISEUR_MONO);
                userRepository.save(marchand);
                System.out.println("✅ Marchandiseur created: marchand / merch123");
            } else {
                System.out.println("ℹ️ Marchandiseur already exists.");
            }
        };
    }
}
