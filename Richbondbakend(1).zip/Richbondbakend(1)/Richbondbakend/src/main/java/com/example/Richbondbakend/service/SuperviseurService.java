package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.Region;
import com.example.Richbondbakend.entity.superviseur;

import java.util.List;
import java.util.Optional;

public interface SuperviseurService {
    // Création avec gestion des IDs de merchandisers
    superviseur saveSuperviseur(superviseur superviseur);

    // Lecture
    Optional<superviseur> getSuperviseurById(Long id);
    List<superviseur> getAllSuperviseurs();

    // Suppression
    void deleteSuperviseurById(Long id);

    // Mise à jour
    superviseur updateSuperviseur(Long id, superviseur superviseurDetails);

    // Recherche
    List<superviseur> findByNom(String nom);
    List<superviseur> findByRegion(Region region);
    Optional<superviseur> findByEmail(String email);

    // Gestion des merchandisers
    List<Merchendiseur> getMerchandiseurs(Long superviseurId);
    superviseur updateStatus(Long id, String status);

    // Méthodes améliorées pour la gestion des relations
    superviseur assignMerchandiseurs(Long superviseurId, List<Long> merchandiseurIds);
    superviseur addMerchendiseurToSuperviseur(Long superviseurId, Merchendiseur merchendiseur);
    superviseur removeMerchendiseurFromSuperviseur(Long superviseurId, Long merchendiseurId);
}