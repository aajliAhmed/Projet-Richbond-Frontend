package com.example.Richbondbakend.controlleur;

import com.example.Richbondbakend.dto.MerchendiseurDTO;
import com.example.Richbondbakend.dto.SuperviseurRequestDTO;
import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.Region;
import com.example.Richbondbakend.entity.superviseur;
import com.example.Richbondbakend.service.MerchendiseurServiceImp;
import com.example.Richbondbakend.service.SuperviseurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping("/api/superviseur")
@CrossOrigin(origins = "http://localhost:4200")
public class SuperviseurControlleur {

    @Autowired
    private SuperviseurService superviseurService;
    private MerchendiseurServiceImp merch;
    private SuperviseurRequestDTO convertToDTO(superviseur superviseur) {
        return new SuperviseurRequestDTO(superviseur);
    }

    @PostMapping("/create")
    public superviseur createSuperviseur(@RequestBody superviseur newSuperviseur) {
      return superviseurService.saveSuperviseur(newSuperviseur);
    }

    @GetMapping("/{id}")
    public superviseur getSuperviseurById(@PathVariable Long id) {
        return superviseurService.getSuperviseurById(id).orElse(null);
    }

    @GetMapping("/all")
    public List<superviseur> getAllSuperviseurs() {
        return superviseurService.getAllSuperviseurs();
    }

    @PutMapping("/{id}")
    public superviseur updateSuperviseur(@PathVariable Long id, @RequestBody superviseur superviseurDetails) {
        return superviseurService.updateSuperviseur(id, superviseurDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteSuperviseur(@PathVariable Long id) {
        superviseurService.deleteSuperviseurById(id);
    }

    @GetMapping("/searchByName/{nom}")
    public List<superviseur> findByNom(@PathVariable String nom) {
        return superviseurService.findByNom(nom);
    }

    @GetMapping("/searchByRegion/{region}")
    public List<superviseur> findByRegion(@PathVariable Region region) {
        return superviseurService.findByRegion(region);
    }

    @GetMapping("/searchByEmail/{email}")
    public superviseur findByEmail(@PathVariable String email) {
        return superviseurService.findByEmail(email).orElse(null);
    }

    @GetMapping("/{superviseurId}/merchandiseurs")
    public List<Merchendiseur> getMerchandiseurs(@PathVariable Long superviseurId) {
        return superviseurService.getMerchandiseurs(superviseurId);
    }

//    @PutMapping("/{id}/status")
//    public superviseur updateStatus(@PathVariable Long id, @RequestBody String status) {
//        return superviseurService.updateStatus(id, status);
//    }
@PutMapping("/status/{id}")
public SuperviseurRequestDTO updateStatus(@PathVariable Long id, @RequestParam String status) {
    superviseur updated = superviseurService.updateStatus(id, status);
    return convertToDTO(updated);
}

    @PostMapping("/{superviseurId}/addMerchendiseur")
    public superviseur addMerchendiseur(@PathVariable Long superviseurId, @RequestBody Merchendiseur merchendiseur) {
        return superviseurService.addMerchendiseurToSuperviseur(superviseurId, merchendiseur);
    }

    @DeleteMapping("/{superviseurId}/removeMerchendiseur/{merchendiseurId}")
    public superviseur removeMerchendiseur(@PathVariable Long superviseurId, @PathVariable Long merchendiseurId) {
        return superviseurService.removeMerchendiseurFromSuperviseur(superviseurId, merchendiseurId);
    }
}
