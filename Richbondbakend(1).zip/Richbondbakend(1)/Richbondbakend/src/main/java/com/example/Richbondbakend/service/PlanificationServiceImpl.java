package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Planification;
import com.example.Richbondbakend.entity.StatutVisite;
import com.example.Richbondbakend.repository.planifRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PlanificationServiceImpl implements PlanificationService {

    @Autowired
    private planifRepository planificationRepository;

    @Override
    public Planification savePlanification(Planification planification) {
        return planificationRepository.save(planification);
    }

    @Override
    public Planification updatePlanification(Long id, Planification planification) {
        Optional<Planification> existing = planificationRepository.findById(id);
        if (existing.isPresent()) {
            planification.setId(id);
            return planificationRepository.save(planification);
        }
        throw new RuntimeException("Planification non trouvée avec ID: " + id);
    }

    @Override
    public void deletePlanification(Long id) {
        planificationRepository.deleteById(id);
    }

    @Override
    public Planification getPlanificationById(Long id) {
        return planificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Planification non trouvée avec ID: " + id));
    }

    @Override
    public List<Planification> getAllPlanifications() {
        return planificationRepository.findAll();
    }

    @Override
    public List<Planification> getPlanificationsByMerchandiserId(Long merchandiserId) {
        return planificationRepository.findByMerchandiserId(merchandiserId);
    }

    @Override
    public List<Planification> getPlanificationsByMagasinId(Long magasinId) {
        return planificationRepository.findByMagasinId(magasinId);
    }

    @Override
    public List<Planification> getPlanificationsByDate(LocalDateTime dateVisite) {
        return planificationRepository.findByDateVisite(dateVisite);
    }

    @Override
    public List<Planification> getPlanificationsBetweenDates(LocalDateTime start, LocalDateTime end) {
        return planificationRepository.findByDateVisiteBetween(start, end);
    }

    @Override
    public List<Planification> getPlanificationsByValidationStatus(boolean valide) {
        return planificationRepository.findByValide(valide);
    }

    @Override
    public List<Planification> getPlanificationsByStatut(String statut) {
        StatutVisite s;
        try {
            s = StatutVisite.valueOf(statut);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Statut non reconnu : " + statut);
        }
        return planificationRepository.findByStatut(s);
    }

    @Override
    public Planification validerPlanification(Long id) {
        Planification planif = getPlanificationById(id);
        planif.setValide(true);
        return planificationRepository.save(planif);
    }

    @Override
    public List<Planification> getPlanningHebdomadaire(Long merchandiserId, LocalDateTime startOfWeek) {
        LocalDateTime endOfWeek = startOfWeek.plusDays(6);
        return planificationRepository.findByMerchandiserIdAndDateVisiteBetween(merchandiserId, startOfWeek, endOfWeek);
    }

    @Override
    public List<Planification> getPlanningJournalier(Long merchandiserId, LocalDateTime date) {
        LocalDateTime startOfDay = date.withHour(0).withMinute(0);
        LocalDateTime endOfDay = date.withHour(23).withMinute(59);
        return planificationRepository.findByMerchandiserIdAndDateVisiteBetween(merchandiserId, startOfDay, endOfDay);
    }
}
