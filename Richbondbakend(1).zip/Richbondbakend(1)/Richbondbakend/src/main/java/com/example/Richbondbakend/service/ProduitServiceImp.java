package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Produit;
import com.example.Richbondbakend.repository.ProduitRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProduitServiceImp implements ProduitService {

    @Autowired
    private ProduitRespository produitRepository;

    @Override
    public Produit createProduit(Produit produit) {
        return produitRepository.save(produit);
    }

    @Override
    public Optional<Produit> getProduitById(Long id) {
        return produitRepository.findById(id);
    }

    @Override
    public List<Produit> getAllProduits() {
        return produitRepository.findAll();
    }

    @Override
    public Produit updateProduit(Long id, Produit updatedProduit) {
        Optional<Produit> optionalProduit = produitRepository.findById(id);
        if (optionalProduit.isPresent()) {
            Produit existingProduit = optionalProduit.get();
            existingProduit.setMarque(updatedProduit.getMarque());
            existingProduit.setReference(updatedProduit.getReference());
            existingProduit.setCategorie(updatedProduit.getCategorie());
            existingProduit.setImage(updatedProduit.getImage());
            existingProduit.setArticle(updatedProduit.getArticle());
            existingProduit.setType(updatedProduit.getType());
            existingProduit.setDimensions(updatedProduit.getDimensions());
            return produitRepository.save(existingProduit);
        } else {
            return null; // Ou lancer une exception personnalisée
        }
    }

    @Override
    @Transactional
    public void deleteProduit(Long id) {
        // Charger le produit AVEC ses associations
        Produit produit = produitRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produit non trouvé avec l'id : " + id));

        // Déclencher manuellement le nettoyage des associations
//        produit.getMagasins().clear(); // Optionnel selon le cas

        // La suppression en cascade se fera automatiquement grâce à CascadeType.REMOVE
        produitRepository.delete(produit);
    }

    @Override
    public List<Produit> getProduitsByMarque(String marque) {
        return produitRepository.findAll().stream()
                .filter(p -> p.getMarque() != null && p.getMarque().equalsIgnoreCase(marque))
                .collect(Collectors.toList());
    }


}
