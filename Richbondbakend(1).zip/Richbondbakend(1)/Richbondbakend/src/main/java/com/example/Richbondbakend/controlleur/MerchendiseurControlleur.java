package com.example.Richbondbakend.controlleur;

import com.example.Richbondbakend.dto.MerchendiseurDTO;
import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.service.MerchendiseurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/merchendiseurs")
@CrossOrigin(origins = "http://localhost:4200")
@PreAuthorize("hasRole('MARCHANDISEUR')") // 🔐 Sécurise tout le contrôleur
public class MerchendiseurControlleur {

    @Autowired
    private MerchendiseurService merchendiseurService;

    // 🔁 Convertit une entité en DTO
    private MerchendiseurDTO convertToDTO(Merchendiseur merchendiseur) {
        return new MerchendiseurDTO(merchendiseur);
    }

    @PostMapping("/add")
    public MerchendiseurDTO save(@RequestBody Merchendiseur merchendiseur) {
        Merchendiseur saved = merchendiseurService.saveMerchendiseur(merchendiseur);
        return convertToDTO(saved);
    }

    @GetMapping("/all")
    public List<Merchendiseur> getAll() {
        return merchendiseurService.getAllMerchendiseurs();
    }

    @GetMapping("/{id}")
    public MerchendiseurDTO getById(@PathVariable Long id) {
        Optional<Merchendiseur> merchendiseur = merchendiseurService.getMerchendiseurById(id);
        return merchendiseur.map(this::convertToDTO).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        merchendiseurService.deleteMerchendiseurById(id);
    }

    @GetMapping("/nom/{nom}")
    public List<MerchendiseurDTO> getByNom(@PathVariable String nom) {
        return merchendiseurService.findByNom(nom).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/region/{region}")
    public List<MerchendiseurDTO> getByRegion(@PathVariable String region) {
        return merchendiseurService.findByRegion(region).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/type/{type}")
    public List<MerchendiseurDTO> getByType(@PathVariable String type) {
        return merchendiseurService.findByType(type).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/superviseur/{superviseurId}")
    public List<MerchendiseurDTO> getBySuperviseur(@PathVariable Long superviseurId) {
        return merchendiseurService.findBySuperviseurId(superviseurId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @PutMapping("/status/{id}")
    public MerchendiseurDTO updateStatus(@PathVariable Long id, @RequestParam String status) {
        Merchendiseur updated = merchendiseurService.updateStatus(id, status);
        return convertToDTO(updated);
    }

    @PutMapping("/update/{id}")
    public MerchendiseurDTO updateMerchendiseur(@PathVariable Long id, @RequestBody Merchendiseur updatedMerchendiseur) {
        Merchendiseur updated = merchendiseurService.updateMerchendiseur(id, updatedMerchendiseur);
        return convertToDTO(updated);
    }
}
