package com.example.Richbondbakend.repository;

import com.example.Richbondbakend.entity.Magasin;
import com.example.Richbondbakend.entity.Region;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MagasinRepository extends JpaRepository<Magasin,Long> {
    List<Magasin> findByRegion(Region enumRegion);

    List<Magasin> findByVilleIgnoreCase(String ville);
}
