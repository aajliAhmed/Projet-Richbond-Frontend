package com.example.Richbondbakend.entity;


import java.util.List;
import jakarta.persistence.*;
@Entity
public class Produit {

    @Id
    @GeneratedValue
    private Long id;



    private String marque;
    private String reference;
    private String categorie;
    @Column(columnDefinition = "LONGTEXT")
    private String image;
    // URL ou base64
    private String article;     // Nom commercial
    private String type;        // Ex: HYPER, MARCHÉ, etc.
    private String dimensions;  // ex: 190×140


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getCategorie() {
        return categorie;
    }

    public void setCategorie(String categorie) {
        this.categorie = categorie;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getArticle() {
        return article;
    }

    public void setArticle(String article) {
        this.article = article;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }


}
