package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Role;
import com.example.Richbondbakend.entity.user;
import com.example.Richbondbakend.repository.SuperviseurRepository;
import com.example.Richbondbakend.repository.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class userServiceImp {
//
//    private final userRepository userRepository;
//
//    private final SuperviseurRepository superviseurRepository;
//
//    @Autowired
//    public userServiceImp(userRepository userRepository, SuperviseurRepository superviseurRepository) {
//        this.userRepository = userRepository;
//
//        this.superviseurRepository = superviseurRepository;
//    }
//
//    @Override
//    public Optional<user> createUser(user user) {
//        if (userRepository.existsByEmail(user.getEmail())) {
//            return Optional.empty();
//        }
//
//
//
//        return Optional.of(userRepository.save(user));
//    }
//
//    @Override
//    public Optional<user> updateUser(Long id, user userDetails) {
//        return userRepository.findById(id)
//                .map(existingUser -> {
//                    if (!existingUser.getEmail().equals(userDetails.getEmail()) &&
//                            userRepository.existsByEmail(userDetails.getEmail())) {
//                        return null;
//                    }
//
//                    existingUser.setNom(userDetails.getNom());
//                    existingUser.setPrenom(userDetails.getPrenom());
//                    existingUser.setEmail(userDetails.getEmail());
//                    existingUser.setTelephone(userDetails.getTelephone());
//                    existingUser.setStatus(userDetails.getStatus());
//                    existingUser.setRole(userDetails.getRole());
//                    existingUser.setRegion(userDetails.getRegion());
//                    existingUser.setVille(userDetails.getVille());
//                    existingUser.setMarqueCouverte(userDetails.getMarqueCouverte());
//
//
//
//                    return userRepository.save(existingUser);
//                })
//                .map(Optional::of)
//                .orElse(Optional.empty());
//    }
//
//    @Override
//    public Boolean deleteUser(Long id) {
//        return userRepository.findById(id)
//                .map(user -> {
//                    userRepository.delete(user);
//                    return true;
//                })
//                .orElse(false);
//    }
//
//    @Override
//    public Optional<user> getUserById(Long id) {
//        return userRepository.findById(id);
//    }
//
//    @Override
//    public List<user> getAllUsers() {
//        return userRepository.findAll();
//    }
//
//    @Override
//    public user changeUserRole(Long userId, Role newRole) {
//        return null;
//    }
//
//
//    @Override
//    public List<user> getUsersByRole(Role role) {
//        return userRepository.findByRole(role);
//    }
//
//    @Override
//    public List<user> searchUsersByName(String name) {
//        return userRepository.findByNomContainingIgnoreCaseOrPrenomContainingIgnoreCase(name, name);
//    }
//
//    @Override
//    public List<user> filterUsersByStatus(String status) {
//        return userRepository.findByStatus(status);
//    }
//
//    @Override
//    public Object deactivateUser(Long userId) {
//        return userRepository.findById(userId)
//                .map(user -> {
//                    user.setStatus("INACTIF");
//                    return userRepository.save(user);
//                });
//    }
//
//    @Override
//    public Optional<user> activateUser(Long userId) {
//        return userRepository.findById(userId)
//                .map(user -> {
//                    user.setStatus("ACTIF");
//                    return userRepository.save(user);
//                });
//    }
//
//    @Override
//    public long countActiveUsers() {
//        return userRepository.countByStatus("ACTIF");
//    }
}