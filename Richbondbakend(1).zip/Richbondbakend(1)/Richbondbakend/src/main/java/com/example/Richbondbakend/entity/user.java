package com.example.Richbondbakend.entity;

import jakarta.persistence.*;
@Entity
public class user {
    @Id
    @GeneratedValue
    private Long id;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    private String email;

    private String username;
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    // Getters et setters existants (sans nom/prenom)
    public Long getId() { return id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }


}