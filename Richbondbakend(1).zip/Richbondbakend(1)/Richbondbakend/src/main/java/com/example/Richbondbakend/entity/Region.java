package com.example.Richbondbakend.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum Region {
    @JsonProperty("Sud")
    SUD,

    @JsonProperty("Nord")
    NORD,

    @JsonProperty("Orient")
    ORIENT,

    @JsonProperty("Centre")
    CENTRE,

    @JsonProperty("Tanger-Tétouan-Al Hoceïma")
    TANGER_TETOUAN_AL_HOCEIMA,

    @JsonProperty("L'Oriental")
    ORIENTAL,

    @JsonProperty("Fès-Meknès")
    FES_MEKNES,

    @JsonProperty("Rabat-Salé-Kénitra")
    RABAT_SALE_KENITRA,

    @JsonProperty("Béni Mellal-Khénifra")
    BENI_MELLAL_KHENIFRA,

    @JsonProperty("Casablanca-Settat")
    CASABLANCA_SETTAT,

    @JsonProperty("Marrakech-Safi")
    MARRAKECH_SAFI,

    @JsonProperty("Drâa-Tafilalet")
    DRAA_TAFILALET,

    @JsonProperty("Souss-Massa")
    SOUSS_MASSA,

    @JsonProperty("Guelmim-Oued Noun")
    GUELMIM_OUED_NOUN,

    @JsonProperty("Laâyoune-Sakia El Hamra")
    LAAYOUNE_SAKIA_EL_HAMRA,

    @JsonProperty("Dakhla-Oued Ed Dahab")
    DAKHLA_OUED_ED_DAHAB
}