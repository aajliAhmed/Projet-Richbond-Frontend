package com.example.Richbondbakend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender emailSender;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    public void sendPasswordResetEmail(String to, String token) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("wannassafaa8@gmail.com");
        message.setTo(to);
        message.setSubject("Réinitialisation de votre mot de passe - Richbond App");
        message.setText("Bonjour,\n\n" +
                "Vous avez demandé la réinitialisation de votre mot de passe pour l'application Richbond.\n\n" +
                "Pour réinitialiser votre mot de passe, veuillez cliquer sur le lien suivant :\n" +
                frontendUrl + "/reset-password?token=" + token + "\n\n" +
                "Ce lien est valable pendant 24 heures.\n\n" +
                "Si vous n'avez pas demandé cette réinitialisation, veuillez ignorer cet email.\n\n" +
                "Cordialement,\n" +
                "L'équipe Richbond");
        
        emailSender.send(message);
    }
} 