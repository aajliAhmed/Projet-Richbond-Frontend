package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Role;
import com.example.Richbondbakend.entity.user;

import java.util.List;
import java.util.Optional;

public interface userService {
//    Optional<user> createUser(user user);
//
//    Optional<user> updateUser(Long id, user userDetails);
//
//    Boolean deleteUser(Long id);
//
//    Optional<user> getUserById(Long id);
//
//    List<user> getAllUsers();
//    //Page<user> getAllUsers(Pageable pageable);
//
//    // Gestion des rôles et permissions
//    user changeUserRole(Long userId, Role newRole);
//
//    List<user> getUsersByRole(Role role);
//
//
//    // Fonctionnalités métier spécifiques
//    List<user> searchUsersByName(String name);
//
//    List<user> filterUsersByStatus(String status);
//
//    Object deactivateUser(Long userId);
//
//    Optional<user> activateUser(Long userId);
//
//
//    long countActiveUsers();
}
