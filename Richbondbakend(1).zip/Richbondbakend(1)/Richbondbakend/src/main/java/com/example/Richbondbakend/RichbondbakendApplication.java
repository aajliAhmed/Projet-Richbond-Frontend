package com.example.Richbondbakend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RichbondbakendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RichbondbakendApplication.class, args);
	}

}

