package com.example.Richbondbakend.entity;

public enum enseignes {
}
