package com.example.Richbondbakend.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Planification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "magasin_id", nullable = false)
    private Magasin magasin;

    @ManyToOne
    @JoinColumn(name = "merchandiser_id", nullable = false)
    private Merchendiseur merchandiser;

    private LocalDateTime dateVisite;

    @Enumerated(EnumType.STRING)
    private StatutVisite statut;

    private String commentaire;

    private Integer dureeVisite;

    private boolean valide;

    private LocalDateTime dateCreation = LocalDateTime.now();

    // Getters et Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Magasin getMagasin() {
        return magasin;
    }

    public void setMagasin(Magasin magasin) {
        this.magasin = magasin;
    }

    public Merchendiseur getMerchandiser() {
        return merchandiser;
    }

    public void setMerchandiser(Merchendiseur merchandiser) {
        this.merchandiser = merchandiser;
    }

    public LocalDateTime getDateVisite() {
        return dateVisite;
    }

    public void setDateVisite(LocalDateTime dateVisite) {
        this.dateVisite = dateVisite;
    }

    public StatutVisite getStatut() {
        return statut;
    }

    public void setStatut(StatutVisite statut) {
        this.statut = statut;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public Integer getDureeVisite() {
        return dureeVisite;
    }

    public void setDureeVisite(Integer dureeVisite) {
        this.dureeVisite = dureeVisite;
    }

    public boolean isValide() {
        return valide;
    }

    public void setValide(boolean valide) {
        this.valide = valide;
    }

    public LocalDateTime getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(LocalDateTime dateCreation) {
        this.dateCreation = dateCreation;
    }
}
