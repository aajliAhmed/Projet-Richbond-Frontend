package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.repository.MerchendiseurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MerchendiseurServiceImp implements MerchendiseurService {

    @Autowired
    private MerchendiseurRepository merchendiseurRepository;

    @Override
    public Merchendiseur saveMerchendiseur(Merchendiseur merchendiseur) {
        return merchendiseurRepository.save(merchendiseur);
    }

    @Override
    public List<Merchendiseur> getAllMerchendiseurs() {
        return merchendiseurRepository.findAll();
    }

    @Override
    public Optional<Merchendiseur> getMerchendiseurById(Long id) {
        return merchendiseurRepository.findById(id);
    }

    @Override
    public void deleteMerchendiseurById(Long id) {
        merchendiseurRepository.deleteById(id);
    }

    @Override
    public List<Merchendiseur> findByNom(String nom) {
        return merchendiseurRepository.findByNom(nom);
    }

    @Override
    public List<Merchendiseur> findByRegion(String region) {
        return merchendiseurRepository.findByRegion(region);
    }

    @Override
    public List<Merchendiseur> findBySuperviseurId(Long superviseurId) {
        return merchendiseurRepository.findBySuperviseur_Id(superviseurId);
    }

    @Override
    public Merchendiseur updateStatus(Long id, String status) {
        Optional<Merchendiseur> optionalMerch = merchendiseurRepository.findById(id);
        if (optionalMerch.isPresent()) {
            Merchendiseur merch = optionalMerch.get();
            merch.setStatus(status);
            return merchendiseurRepository.save(merch);
        }
        return null;
    }

    @Override
    public List<Merchendiseur> findByType(String type) {
        return merchendiseurRepository.findByType(type);
    }
    @Override
    public Merchendiseur updateMerchendiseur(Long id, Merchendiseur updatedMerchendiseur) {
        Optional<Merchendiseur> existingOpt = merchendiseurRepository.findById(id);

        if (existingOpt.isPresent()) {
            Merchendiseur existing = existingOpt.get();

            existing.setNom(updatedMerchendiseur.getNom());
            existing.setPrenom(updatedMerchendiseur.getPrenom());
            existing.setRegion(updatedMerchendiseur.getRegion());
            existing.setVille(updatedMerchendiseur.getVille());
            existing.setMarqueCouverte(updatedMerchendiseur.getMarqueCouverte());
            existing.setLocalisation(updatedMerchendiseur.getLocalisation());
            existing.setStatus(updatedMerchendiseur.getStatus());
            existing.setType(updatedMerchendiseur.getType());
            existing.setEmail(updatedMerchendiseur.getEmail());
//            existing.setSuperviseur(updatedMerchendiseur.getSuperviseur());
            existing.setMagasinIds(updatedMerchendiseur.getMagasinIds());
            existing.setMarques(updatedMerchendiseur.getMarques());
           // existing.setMarques(updatedMerchendiseur.getEnseignes());
            existing.setEnseignes(updatedMerchendiseur.getEnseignes());
            existing.setTelephone(updatedMerchendiseur.getTelephone());

            return merchendiseurRepository.save(existing);
        } else {
            throw new RuntimeException("Merchendiseur non trouvé avec l'id : " + id);
        }
    }

}
