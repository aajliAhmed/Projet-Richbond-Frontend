package com.example.Richbondbakend.repository;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.superviseur;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MerchendiseurRepository extends JpaRepository<Merchendiseur,Long> {
    List<Merchendiseur> findByNom(String nom);

    List<Merchendiseur> findByRegion(String region);

    List<Merchendiseur> findBySuperviseur_Id(Long superviseurId);

    List<Merchendiseur> findByType(String type);
}
