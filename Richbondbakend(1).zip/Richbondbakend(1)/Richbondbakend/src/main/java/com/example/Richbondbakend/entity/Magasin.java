package com.example.Richbondbakend.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Magasin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String Nom;
    private String localisation;
    private Region region;
    private String ville;
    private String type;
    private String enseigne;
    @ManyToMany
    @JoinTable(
            name = "magasin_produit",
            joinColumns = @JoinColumn(name = "magasin_id"),
            inverseJoinColumns = @JoinColumn(name = "produit_id")
    )
    private List<Produit> produits;

    public void setProduits(List<Produit> produits) {
        this.produits = produits;
    }

    public List<Produit> getProduits() {
        return produits;
    }
    @ManyToOne
    @JoinColumn(name = "merchandiseur_id")
//    @JsonIgnoreProperties("magasins") // Ignore la propriété 'magasins' dans Merchendiseur
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Merchendiseur merchandiseur;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEnseigne() {
        return enseigne;
    }

    public void setEnseigne(String enseigne) {
        this.enseigne = enseigne;
    }

    public Merchendiseur getMerchandiseur() {
        return merchandiseur;
    }

    public void setMerchandiseur(Merchendiseur merchandiseur) {
        this.merchandiseur = merchandiseur;
    }

}
