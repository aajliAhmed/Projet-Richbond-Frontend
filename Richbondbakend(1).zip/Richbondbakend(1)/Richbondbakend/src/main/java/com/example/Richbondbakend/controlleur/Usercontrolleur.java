package com.example.Richbondbakend.controlleur;

import com.example.Richbondbakend.entity.Role;
import com.example.Richbondbakend.entity.user;
import com.example.Richbondbakend.service.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/users")
public class Usercontrolleur {
//
//    private final userService userService;
//
//    @Autowired
//    public Usercontrolleur(userService userService) {
//        this.userService = userService;
//    }
//
//    @PostMapping("/add")
//    @ResponseStatus(HttpStatus.CREATED)
//    public user createUser(@RequestBody user user) {
//        return userService.createUser(user)
//                .orElseThrow(() -> new RuntimeException("Email déjà utilisé"));
//    }
//
//    @PutMapping("/{id}")
//    public user updateUser(@PathVariable Long id, @RequestBody user userDetails) {
//        return userService.updateUser(id, userDetails)
//                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));
//    }
//
//    @DeleteMapping("/{id}")
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public void deleteUser(@PathVariable Long id) {
//        if (!userService.deleteUser(id)) {
//            throw new RuntimeException("Utilisateur non trouvé");
//        }
//    }
//
//    @GetMapping("/{id}")
//    public user getUserById(@PathVariable Long id) {
//        return userService.getUserById(id)
//                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));
//    }
//
//    @GetMapping("/all")
//    public List<user> getAllUsers() {
//        return userService.getAllUsers();
//    }
//
//    @PutMapping("/{userId}/role/{role}")
//    public user changeUserRole(@PathVariable Long userId, @PathVariable Role role) {
//        return userService.changeUserRole(userId, role);
//
//
//    }
//
//    @GetMapping("/role/{role}")
//    public List<user> getUsersByRole(@PathVariable Role role) {
//        return userService.getUsersByRole(role);
//    }
//
//    @GetMapping("/search")
//    public List<user> searchUsersByName(@RequestParam String name) {
//        return userService.searchUsersByName(name);
//    }
//
//    @GetMapping("/filter")
//    public List<user> filterUsersByStatus(@RequestParam String status) {
//        return userService.filterUsersByStatus(status);
//    }
//
//    @PutMapping("/{userId}/deactivate")
//    public user deactivateUser(@PathVariable Long userId) {
//        return (user) userService.deactivateUser(userId);
//
//    }
//
//    @PutMapping("/{userId}/activate")
//    public user activateUser(@PathVariable Long userId) {
//        return userService.activateUser(userId)
//                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));
//    }
//
//    @GetMapping("/stats/active")
//    public long countActiveUsers() {
//        return userService.countActiveUsers();
//    }
}