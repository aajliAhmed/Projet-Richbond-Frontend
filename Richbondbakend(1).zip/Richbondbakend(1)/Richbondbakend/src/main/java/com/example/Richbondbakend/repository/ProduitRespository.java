package com.example.Richbondbakend.repository;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.Produit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProduitRespository extends JpaRepository<Produit,Long> {
}
