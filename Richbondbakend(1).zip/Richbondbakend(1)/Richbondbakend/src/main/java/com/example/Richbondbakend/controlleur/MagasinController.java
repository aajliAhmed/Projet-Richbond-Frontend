package com.example.Richbondbakend.controlleur;

import com.example.Richbondbakend.entity.Magasin;
import com.example.Richbondbakend.exception.EntityNotFoundException;
import com.example.Richbondbakend.exception.IllegalOperationException;
import com.example.Richbondbakend.service.MagasinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/magasins")
@CrossOrigin(origins = "http://localhost:4200")
public class MagasinController {

    private final MagasinService magasinService;

    @Autowired
    public MagasinController(MagasinService magasinService) {
        this.magasinService = magasinService;
    }

    @PostMapping("/create")
    public ResponseEntity<?> createMagasin(@RequestBody Magasin magasin) {
        try {
            Magasin savedMagasin = magasinService.saveMagasin(magasin);
            return new ResponseEntity<>(savedMagasin, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la création du magasin: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getMagasinById(@PathVariable Long id) {
        try {
            Magasin magasin = magasinService.getMagasinById(id);
            return ResponseEntity.ok(magasin);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/all")
    public  List<Magasin> getAllMagasins() {
        List<Magasin> magasins = magasinService.getAllMagasins();
        return magasinService.getAllMagasins();
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateMagasin(@PathVariable Long id, @RequestBody Magasin magasin) {
        try {
            Magasin updatedMagasin = magasinService.updateMagasin(id, magasin);
            return ResponseEntity.ok(updatedMagasin);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la mise à jour: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteMagasin(@PathVariable Long id) {
        try {
            magasinService.deleteMagasin(id);
            return ResponseEntity.noContent().build();
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (IllegalOperationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

    @GetMapping("/region/{region}")
    public ResponseEntity<?> getMagasinsByRegion(@PathVariable String region) {
        try {
            List<Magasin> magasins = magasinService.getMagasinsByRegion(region);
            return ResponseEntity.ok(magasins);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/ville/{ville}")
    public ResponseEntity<?> getMagasinsByVille(@PathVariable String ville) {
        List<Magasin> magasins = magasinService.getMagasinsByVille(ville);
        if (magasins.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }
        return ResponseEntity.ok(magasins);
    }
}
