package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.Region;
import com.example.Richbondbakend.entity.superviseur;
import com.example.Richbondbakend.repository.SuperviseurRepository;
import com.example.Richbondbakend.repository.MerchendiseurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class SuperviseurServiceImp implements SuperviseurService {

    private final SuperviseurRepository superviseurRepository;
    private final MerchendiseurRepository merchendiseurRepository;

    @Autowired
    public SuperviseurServiceImp(SuperviseurRepository superviseurRepository,
                                 MerchendiseurRepository merchendiseurRepository) {
        this.superviseurRepository = superviseurRepository;
        this.merchendiseurRepository = merchendiseurRepository;
    }

    @Override
    public superviseur saveSuperviseur(superviseur superviseur) {
        if (superviseur.getMerchendiseurs() != null && !superviseur.getMerchendiseurs().isEmpty()) {
            List<Merchendiseur> merchendiseurs = superviseur.getMerchendiseurs().stream()
                    .map(m -> merchendiseurRepository.findById(m.getId())
                            .orElseThrow(() -> new RuntimeException("Merchendiseur non trouvé avec id " + m.getId())))
                    .peek(m -> m.setSuperviseur(superviseur))
                    .toList();

            superviseur.setMerchendiseurs(merchendiseurs);
        }
        return superviseurRepository.save(superviseur);
    }

    @Override
    public Optional<superviseur> getSuperviseurById(Long id) {
        return superviseurRepository.findById(id);
    }

    @Override
    public List<superviseur> getAllSuperviseurs() {
        return superviseurRepository.findAll();
    }

    @Override
    public void deleteSuperviseurById(Long id) {
        superviseurRepository.findById(id).ifPresent(superviseur -> {
            superviseur.getMerchendiseurs().forEach(m -> m.setSuperviseur(null));
            superviseurRepository.delete(superviseur);
        });
    }

    @Override
    public superviseur updateSuperviseur(Long id, superviseur superviseurDetails) {
        return superviseurRepository.findById(id).map(superviseur -> {
            superviseur.setNom(superviseurDetails.getNom());
            superviseur.setPrenom(superviseurDetails.getPrenom());
            superviseur.setVille(superviseurDetails.getVille());
            superviseur.setStatus(superviseurDetails.getStatus());
            superviseur.setEmail(superviseurDetails.getEmail());
            superviseur.setRegion(superviseurDetails.getRegion());
            superviseur.setTelephone(superviseurDetails.getTelephone());

            if (superviseurDetails.getMerchendiseurIds() != null) {
                // Liste actuelle
                List<Merchendiseur> currentMerchList = superviseur.getMerchendiseurs();

                // Liste des IDs reçus (ceux qu’on veut garder ou ajouter)
                List<Long> newIds = superviseurDetails.getMerchendiseurIds();

                // Merch à supprimer (présents avant, mais pas dans la nouvelle liste)
                List<Merchendiseur> toRemove = currentMerchList.stream()
                        .filter(m -> !newIds.contains(m.getId()))
                        .toList();

                // Merch à ajouter (présents dans la nouvelle liste mais pas encore assignés)
                List<Merchendiseur> toAdd = newIds.stream()
                        .filter(idMerch -> currentMerchList.stream().noneMatch(m -> m.getId().equals(idMerch)))
                        .map(idMerch -> merchendiseurRepository.findById(idMerch)
                                .orElseThrow(() -> new RuntimeException("Merchendiseur non trouvé avec id " + idMerch)))
                        .toList();

                // Retirer les anciens si besoin
                toRemove.forEach(m -> m.setSuperviseur(null));
                currentMerchList.removeAll(toRemove);

                // Ajouter les nouveaux
                toAdd.forEach(m -> {
                    m.setSuperviseur(superviseur);
                    currentMerchList.add(m);
                });

                // Mise à jour finale
                superviseur.setMerchendiseurs(currentMerchList);
            }

            return superviseurRepository.save(superviseur);
        }).orElse(null);
    }

    @Override
    public List<superviseur> findByNom(String nom) {
        return superviseurRepository.findByNom(nom);
    }

    @Override
    public List<superviseur> findByRegion(Region region) {
        return superviseurRepository.findByRegion(region);
    }

    @Override
    public Optional<superviseur> findByEmail(String email) {
        return superviseurRepository.findByEmail(email);
    }

    @Override
    public List<Merchendiseur> getMerchandiseurs(Long superviseurId) {
        return superviseurRepository.findById(superviseurId)
                .map(superviseur::getMerchendiseurs)
                .orElse(List.of());
    }

    @Override
    public superviseur updateStatus(Long id, String status) {
        return superviseurRepository.findById(id)
                .map(superviseur -> {
                    superviseur.setStatus(status);
                    return superviseurRepository.save(superviseur);
                })
                .orElse(null);
    }

    @Override
    public superviseur assignMerchandiseurs(Long superviseurId, List<Long> merchandiseurIds) {
        return superviseurRepository.findById(superviseurId)
                .map(superviseur -> {
                    // Détacher tous les merchandisers précédents
                    superviseur.getMerchendiseurs().forEach(m -> m.setSuperviseur(null));

                    // Assigner les nouveaux
                    List<Merchendiseur> newMerchList = merchandiseurIds.stream()
                            .map(id -> merchendiseurRepository.findById(id)
                                    .orElseThrow(() -> new RuntimeException("Merchendiseur non trouvé avec id " + id)))
                            .peek(m -> m.setSuperviseur(superviseur))
                            .collect(Collectors.toList());

                    superviseur.setMerchendiseurs(newMerchList);

                    return superviseurRepository.save(superviseur);
                })
                .orElse(null);
    }

    @Override
    public superviseur addMerchendiseurToSuperviseur(Long superviseurId, Merchendiseur merchendiseur) {
        return superviseurRepository.findById(superviseurId)
                .map(superviseur -> {
                    merchendiseur.setSuperviseur(superviseur);
                    Merchendiseur savedMerch = merchendiseurRepository.save(merchendiseur);
                    superviseur.getMerchendiseurs().add(savedMerch);
                    return superviseurRepository.save(superviseur);
                })
                .orElse(null);
    }

    @Override
    public superviseur removeMerchendiseurFromSuperviseur(Long superviseurId, Long merchendiseurId) {
        return superviseurRepository.findById(superviseurId)
                .map(superviseur -> {
                    merchendiseurRepository.findById(merchendiseurId).ifPresent(merchendiseur -> {
                        superviseur.getMerchendiseurs().remove(merchendiseur);
                        merchendiseur.setSuperviseur(null);
                        merchendiseurRepository.save(merchendiseur);
                    });
                    return superviseurRepository.save(superviseur);
                })
                .orElse(null);
    }
}
