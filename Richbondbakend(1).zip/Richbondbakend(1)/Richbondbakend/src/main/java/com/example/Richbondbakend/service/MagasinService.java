package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Magasin;

import java.util.List;

public interface MagasinService {
    Magasin saveMagasin(Magasin magasin);                  // Ajouter un magasin
    Magasin getMagasinById(Long id);                       // Récupérer un magasin par ID
    List<Magasin> getAllMagasins();                        // Récupérer tous les magasins
    Magasin updateMagasin(Long id, Magasin magasin);       // Modifier un magasin
    void deleteMagasin(Long id);                           // Supprimer un magasin

    List<Magasin> getMagasinsByRegion(String region);      // Récupérer par région (optionnel)
    List<Magasin> getMagasinsByVille(String ville);
}
