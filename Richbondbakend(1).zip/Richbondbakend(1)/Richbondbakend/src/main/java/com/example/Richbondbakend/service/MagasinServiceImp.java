package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Magasin;
import com.example.Richbondbakend.entity.Region;
import com.example.Richbondbakend.exception.EntityNotFoundException;
import com.example.Richbondbakend.repository.MagasinRepository;
import com.example.Richbondbakend.repository.MerchendiseurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class MagasinServiceImp implements MagasinService {

    private final MagasinRepository repository;
    private final MerchendiseurRepository merchendiseurRepository;

    @Autowired
    public MagasinServiceImp(
            MagasinRepository repository,
            MerchendiseurRepository merchendiseurRepository
    ) {
        this.repository = repository;
        this.merchendiseurRepository = merchendiseurRepository;
    }

    @Override
    @Transactional
    public Magasin saveMagasin(Magasin magasin) {
        return repository.save(magasin);
    }

    @Override
    public Magasin getMagasinById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Magasin non trouvé avec l'ID: " + id));
    }

    @Override
    public List<Magasin> getAllMagasins() {
        return repository.findAll();
    }

    @Override
    @Transactional
    public Magasin updateMagasin(Long id, Magasin magasinUpdate) {
        Magasin existingMagasin = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Magasin non trouvé avec l'ID: " + id));

        // Mise à jour partielle des champs
        if (magasinUpdate.getNom() != null) {
            existingMagasin.setNom(magasinUpdate.getNom());
        }
        if (magasinUpdate.getLocalisation() != null) {
            existingMagasin.setLocalisation(magasinUpdate.getLocalisation());
        }
        if (magasinUpdate.getRegion() != null) {
            existingMagasin.setRegion(magasinUpdate.getRegion());
        }
        if (magasinUpdate.getVille() != null) {
            existingMagasin.setVille(magasinUpdate.getVille());
        }
        if (magasinUpdate.getType() != null) {
            existingMagasin.setType(magasinUpdate.getType());
        }
        if (magasinUpdate.getEnseigne() != null) {
            existingMagasin.setEnseigne(magasinUpdate.getEnseigne());
        }
        if (magasinUpdate.getMerchandiseur() != null && magasinUpdate.getMerchandiseur().getId() != null) {
            existingMagasin.setMerchandiseur(
                    merchendiseurRepository.getReferenceById(magasinUpdate.getMerchandiseur().getId())
            );
        }

        return repository.save(existingMagasin);
    }

    @Override
    @Transactional
    public void deleteMagasin(Long id) {
        Magasin magasin = repository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Magasin non trouvé avec l'ID: " + id));

        // Validation métier : empêche la suppression si un merchandiser est associé
        if (magasin.getMerchandiseur() != null) {
            throw new IllegalStateException("Impossible de supprimer : Magasin associé à un merchandiser");
        }

        repository.delete(magasin);
    }

    @Override
    public List<Magasin> getMagasinsByRegion(String region) {
        try {
            Region enumRegion = Region.valueOf(region.toUpperCase());
            return repository.findByRegion(enumRegion);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Région invalide: " + region);
        }
    }

    @Override
    public List<Magasin> getMagasinsByVille(String ville) {
        return repository.findByVilleIgnoreCase(ville);
    }
}