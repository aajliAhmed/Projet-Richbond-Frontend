package com.example.Richbondbakend.repository;

import com.example.Richbondbakend.entity.Role;
import com.example.Richbondbakend.entity.user;
import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface userRepository  extends JpaRepository<user,Long> {
    Optional<Object> findByUsername(String username);

    Optional<Object> findByEmail(String email);

//    List<user> findByRole(Role role);
//
////    List<user> findByStatus(String status);
//
//    List<user> findByNomContainingIgnoreCaseOrPrenomContainingIgnoreCase(String name, String name1);
//
////    long countByStatus(String actif);
//
////    boolean existsByEmail(String email);
//    Optional<user> findByUsername(String username);


}
