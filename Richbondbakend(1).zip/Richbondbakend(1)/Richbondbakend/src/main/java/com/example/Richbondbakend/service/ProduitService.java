package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Produit;

import java.util.List;
import java.util.Optional;

public interface ProduitService {
    Produit createProduit(Produit produit);

    // Récupérer un produit par son ID
    Optional<Produit> getProduitById(Long id);

    // Récupérer tous les produits
    List<Produit> getAllProduits();

    // Mettre à jour un produit existant
    Produit updateProduit(Long id, Produit produit);

    // Supprimer un produit par son ID
    void deleteProduit(Long id);

    // Récupérer les produits par marque
    List<Produit> getProduitsByMarque(String marque);


}
