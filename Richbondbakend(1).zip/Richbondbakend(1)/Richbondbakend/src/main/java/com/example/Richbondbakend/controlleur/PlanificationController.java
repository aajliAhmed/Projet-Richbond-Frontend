package com.example.Richbondbakend.controlleur;

import com.example.Richbondbakend.entity.Planification;
import com.example.Richbondbakend.service.PlanificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/planifications")
public class PlanificationController {

    @Autowired
    private PlanificationService planificationService;

    // Créer une planification
    @PostMapping
    public ResponseEntity<Planification> createPlanification(@RequestBody Planification planification) {
        Planification saved = planificationService.savePlanification(planification);
        return ResponseEntity.ok(saved);
    }

    // Modifier une planification
    @PutMapping("/{id}")
    public ResponseEntity<Planification> updatePlanification(@PathVariable Long id,
                                                             @RequestBody Planification planification) {
        Planification updated = planificationService.updatePlanification(id, planification);
        return ResponseEntity.ok(updated);
    }

    // Supprimer une planification
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlanification(@PathVariable Long id) {
        planificationService.deletePlanification(id);
        return ResponseEntity.noContent().build();
    }

    // Récupérer une planification par ID
    @GetMapping("/{id}")
    public ResponseEntity<Planification> getPlanificationById(@PathVariable Long id) {
        Planification planification = planificationService.getPlanificationById(id);
        return ResponseEntity.ok(planification);
    }

    // Récupérer toutes les planifications
    @GetMapping
    public ResponseEntity<List<Planification>> getAllPlanifications() {
        List<Planification> list = planificationService.getAllPlanifications();
        return ResponseEntity.ok(list);
    }

    // Rechercher par merchandiser
    @GetMapping("/merchandiser/{merchandiserId}")
    public ResponseEntity<List<Planification>> getByMerchandiser(@PathVariable Long merchandiserId) {
        List<Planification> list = planificationService.getPlanificationsByMerchandiserId(merchandiserId);
        return ResponseEntity.ok(list);
    }

    // Rechercher par magasin
    @GetMapping("/magasin/{magasinId}")
    public ResponseEntity<List<Planification>> getByMagasin(@PathVariable Long magasinId) {
        List<Planification> list = planificationService.getPlanificationsByMagasinId(magasinId);
        return ResponseEntity.ok(list);
    }

    // Rechercher par date visite précise
    @GetMapping("/date")
    public ResponseEntity<List<Planification>> getByDate(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<Planification> list = planificationService.getPlanificationsByDate(date);
        return ResponseEntity.ok(list);
    }

    // Rechercher entre deux dates
    @GetMapping("/dates")
    public ResponseEntity<List<Planification>> getBetweenDates(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        List<Planification> list = planificationService.getPlanificationsBetweenDates(start, end);
        return ResponseEntity.ok(list);
    }

    // Rechercher par statut validation
    @GetMapping("/valide/{valide}")
    public ResponseEntity<List<Planification>> getByValidation(@PathVariable boolean valide) {
        List<Planification> list = planificationService.getPlanificationsByValidationStatus(valide);
        return ResponseEntity.ok(list);
    }

    // Rechercher par statut visite
    @GetMapping("/statut/{statut}")
    public ResponseEntity<List<Planification>> getByStatut(@PathVariable String statut) {
        List<Planification> list = planificationService.getPlanificationsByStatut(statut);
        return ResponseEntity.ok(list);
    }

    // Valider une planification
    @PutMapping("/valider/{id}")
    public ResponseEntity<Planification> validerPlanification(@PathVariable Long id) {
        Planification planification = planificationService.validerPlanification(id);
        return ResponseEntity.ok(planification);
    }

    // Planning hebdomadaire d’un merchandiser
    @GetMapping("/hebdomadaire/{merchandiserId}")
    public ResponseEntity<List<Planification>> getPlanningHebdomadaire(
            @PathVariable Long merchandiserId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startOfWeek) {
        List<Planification> list = planificationService.getPlanningHebdomadaire(merchandiserId, startOfWeek);
        return ResponseEntity.ok(list);
    }

    // Planning journalier d’un merchandiser
    @GetMapping("/journalier/{merchandiserId}")
    public ResponseEntity<List<Planification>> getPlanningJournalier(
            @PathVariable Long merchandiserId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime date) {
        List<Planification> list = planificationService.getPlanningJournalier(merchandiserId, date);
        return ResponseEntity.ok(list);
    }
}
