package com.example.Richbondbakend.service;

import com.example.Richbondbakend.repository.userRepository;
import com.example.Richbondbakend.dto.LoginRequest;
import com.example.Richbondbakend.dto.LoginResponse;
import com.example.Richbondbakend.entity.user;

import com.example.Richbondbakend.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private userRepository userRepo;

//    @Autowired
//    private PasswordResetTokenRepository tokenRepository;
//
//    @Autowired
//    private JavaMailSender mailSender;

    @Autowired
    private JwtUtil jwtUtil;

    public LoginResponse login(LoginRequest request) {
        user user = (com.example.Richbondbakend.entity.user) userRepo.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!new BCryptPasswordEncoder().matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtil.generateToken(user.getUsername(), user.getRole().name());
        return new LoginResponse(token, user.getRole().name());
    }
//
//    public void forgotPassword(String username) {
//        user user = (com.example.Richbondbakend.entity.user) userRepo.findByUsername(username)
//                .orElseThrow(() -> new RuntimeException("Aucun utilisateur avec ce nom d'utilisateur"));
//
//        String token = UUID.randomUUID().toString();
//        PasswordResetToken resetToken = new PasswordResetToken(token, user, LocalDateTime.now().plusHours(1));
//        tokenRepository.save(resetToken);
//
//        String resetLink = "http://localhost:4200/reset-password?token=" + token;
//
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setTo(user.getEmail()); // Assure-toi que ce champ existe dans l'entité user
//        message.setSubject("Réinitialisation du mot de passe");
//        message.setText("Bonjour " + user.getUsername() + ",\n\n" +
//                "Cliquez sur le lien suivant pour réinitialiser votre mot de passe :\n" +
//                resetLink + "\n\n" +
//                "Ce lien expirera dans 1 heure.");
//        mailSender.send(message);
//    }
//
//    public void resetPassword(String token, String newPassword) {
//        PasswordResetToken resetToken = tokenRepository.findByToken(token)
//                .orElseThrow(() -> new RuntimeException("Token invalide"));
//
//        if (resetToken.getExpiryDate().isBefore(LocalDateTime.now())) {
//            throw new RuntimeException("Le token a expiré");
//        }
//
//        user user = resetToken.getUser();
//        user.setPassword(new BCryptPasswordEncoder().encode(newPassword));
//        userRepo.save(user);
//
//        tokenRepository.delete(resetToken); // facultatif
//    }
}
