package com.example.Richbondbakend.repository;

import com.example.Richbondbakend.entity.Merchendiseur;
import com.example.Richbondbakend.entity.Planification;
import com.example.Richbondbakend.entity.StatutVisite;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface planifRepository extends JpaRepository<Planification,Long>  {

    List<Planification> findByMerchandiserId(Long merchandiserId);

    List<Planification> findByMagasinId(Long magasinId);

    List<Planification> findByDateVisite(LocalDateTime dateVisite);

    List<Planification> findByDateVisiteBetween(LocalDateTime start, LocalDateTime end);

    List<Planification> findByValide(boolean valide);

    List<Planification> findByStatut(StatutVisite s);

    List<Planification> findByMerchandiserIdAndDateVisiteBetween(Long merchandiserId, LocalDateTime startOfWeek, LocalDateTime endOfWeek);
}
