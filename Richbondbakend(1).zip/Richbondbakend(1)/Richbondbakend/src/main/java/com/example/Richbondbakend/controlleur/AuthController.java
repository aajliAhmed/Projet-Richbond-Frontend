package com.example.Richbondbakend.controlleur;


import com.example.Richbondbakend.dto.LoginRequest;
import com.example.Richbondbakend.security.TokenBlacklist;
import com.example.Richbondbakend.service.AuthService;
import com.example.Richbondbakend.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class AuthController {

    @Autowired
    private AuthService authService;
    private final TokenBlacklist tokenBlacklist;

    public AuthController(TokenBlacklist tokenBlacklist) {
        this.tokenBlacklist = tokenBlacklist;
    }

    @PostMapping("/login")
    public ResponseEntity<com.example.Richbondbakend.dto.LoginResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
//    @PostMapping("/forgot-password")
//    public ResponseEntity<String> forgotPassword(@RequestParam String email) {
//        authService.forgotPassword(email);
//        return ResponseEntity.ok("Un email a été envoyé avec le lien de réinitialisation.");
//    }
//
//    @PostMapping("/reset-password")
//    public ResponseEntity<String> resetPassword(@RequestParam String token, @RequestParam String newPassword) {
//        authService.resetPassword(token, newPassword);
//        return ResponseEntity.ok("Mot de passe réinitialisé.");
//    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestHeader("Authorization") String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            tokenBlacklist.add(token);
        }
        return ResponseEntity.ok("Déconnecté avec succès.");
    }
    @Autowired
    private EmailService emailService;

    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody String email) {
        try {
            // Générer un token unique
            String token = UUID.randomUUID().toString();

            // Envoyer l'email
            emailService.sendPasswordResetEmail(email, token);

            return ResponseEntity.ok().body("Email envoyé avec succès");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de l'envoi de l'email");
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestParam String token, @RequestBody String newPassword) {
        try {
            // Ici, vous devrez implémenter la logique pour vérifier le token et mettre à jour le mot de passe
            // Pour l'instant, nous retournons juste un succès
            return ResponseEntity.ok().body("Mot de passe réinitialisé avec succès");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur lors de la réinitialisation du mot de passe");
        }
    }
}