package com.example.Richbondbakend.service;

import com.example.Richbondbakend.entity.Merchendiseur;

import java.util.List;
import java.util.Optional;

public interface MerchendiseurService {

    // Créer ou mettre à jour un merchendiseur
    Merchendiseur saveMerchendiseur(Merchendiseur merchendiseur);

    // Obtenir tous les merchendiseurs
    List<Merchendiseur> getAllMerchendiseurs();

    // Obtenir un merchendiseur par son ID
    Optional<Merchendiseur> getMerchendiseurById(Long id);

    // Supprimer un merchendiseur par ID
    void deleteMerchendiseurById(Long id);

    // Chercher par nom (optionnel)
    List<Merchendiseur> findByNom(String nom);

    // Chercher par région
    List<Merchendiseur> findByRegion(String region);

    // Chercher par superviseur
    List<Merchendiseur> findBySuperviseurId(Long superviseurId);

    // Mettre à jour le status (actif/inactif par exemple)
    Merchendiseur updateStatus(Long id, String status);

    // Filtrer par type (mono-marque / multi-marques)
    List<Merchendiseur> findByType(String type);

    Merchendiseur updateMerchendiseur(Long id, Merchendiseur updatedMerchendiseur);
}
