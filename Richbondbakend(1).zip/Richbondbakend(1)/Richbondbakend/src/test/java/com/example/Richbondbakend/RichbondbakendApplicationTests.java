package com.example.Richbondbakend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RichbondbakendApplicationTests {

	@Test
	void contextLoads() {
	}

}
